Wordpress Theme for my blog
============================

Feature: 
1. Two columns
2. Equal height columns
3. SEO friendly

Base on toolbox theme. GPL license. Welcome to customize.

Demo: [http://mzhou.me](http://mzhou.me)
